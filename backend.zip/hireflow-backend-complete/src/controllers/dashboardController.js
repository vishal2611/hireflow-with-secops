const {
  User,
  Job,
  Application,
  Interview,
  InterviewFeedback,
  CandidateProfile,
  InterviewRound
} = require("../models");
const { Op } = require("sequelize");

async function hrDashboard(req, res) {
  try {
    const companyId = req.user.companyId;

    const [candidateCount, openJobs, upcomingInterviews, pendingFeedback] =
      await Promise.all([
        User.count({
          where: {
            role: "candidate"
          },
          include: [{
            model: Job,
            as: "jobs",
            required: false
          }]
        }).catch(() => 0),

        Job.count({
          where: {
            companyId,
            status: "open"
          }
        }),

        Interview.findAll({
          where: {
            status: {
              [Op.in]: ["scheduled", "rescheduled"]
            },
            scheduledAt: {
              [Op.gte]: new Date()
            }
          },
          include: [{
            model: Application,
            as: "application",
            required: true,
            include: [
              {
                model: User,
                as: "candidate",
                attributes: ["id", "fullName", "email"]
              },
              {
                model: Job,
                as: "job",
                where: { companyId },
                attributes: ["id", "title"]
              }
            ]
          }],
          order: [["scheduledAt", "ASC"]],
          limit: 10
        }),

        Interview.findAll({
          where: {
            status: "completed"
          },
          include: [{
            model: Application,
            as: "application",
            required: true,
            include: [{
              model: Job,
              as: "job",
              where: { companyId },
              attributes: ["id", "title"]
            }]
          }],
          limit: 50
        })
      ]);

    return res.json({
      stats: {
        candidates: candidateCount,
        openJobs,
        upcomingInterviews: upcomingInterviews.length,
        pendingFeedback: pendingFeedback.filter((i) => !i.feedback).length
      },
      upcomingInterviews
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: "Unable to load HR dashboard" });
  }
}

async function candidateDashboard(req, res) {
  try {
    const candidateId = req.user.id;

    const applications = await Application.findAll({
      where: { candidateId },
      include: [
        {
          model: Job,
          as: "job",
          attributes: [
            "id",
            "title",
            "department",
            "location",
            "employmentType",
            "status"
          ]
        },
        {
          model: InterviewRound,
          as: "currentRound",
          attributes: ["id", "name", "roundOrder", "interviewType"]
        },
        {
          model: Interview,
          as: "interviews",
          separate: true,
          order: [["scheduledAt", "DESC"]],
          include: [
            {
              model: InterviewRound,
              as: "round",
              attributes: ["id", "name", "roundOrder", "interviewType"]
            },
            {
              model: InterviewFeedback,
              as: "feedback",
              required: false
            }
          ]
        }
      ],
      order: [["appliedAt", "DESC"]]
    });

    return res.json({
      applications
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: "Unable to load candidate dashboard" });
  }
}

module.exports = {
  hrDashboard,
  candidateDashboard
};
